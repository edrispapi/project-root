from channels.generic.websocket import AsyncWebsocketConsumer
import json

class LiveUpdateConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()

    async def receive(self, text_data):
        data = json.loads(text_data)
        user_id = data.get("user_id")
        entry_data = data.get("entry_data")

        await self.send(text_data=json.dumps({
            "user_id": user_id,
            "message": "داده جدید دریافت شد",
            "entry_data": entry_data
        }))
        
        
        