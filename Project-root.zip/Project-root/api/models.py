from django.db import models
import uuid

class UserAdmin(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True) 
    
    # ایجاد شناسه منحصربه‌فرد
    
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=255)
    family = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    roles = models.JSONField()

class DataEntry(models.Model):
    user = models.ForeignKey(UserAdmin, on_delete=models.CASCADE, related_name="entries")
    entry_data = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)