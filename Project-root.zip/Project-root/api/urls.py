from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DataEntryViewSet
from .consumers import LiveUpdateConsumer

router = DefaultRouter()
router.register(r'entries', DataEntryViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path("ws/live-updates/", LiveUpdateConsumer.as_asgi()),  # مسیر WebSocket
]