from django.test import TestCase
from .models import UserAdmin

class UserAdminTestCase(TestCase):
    def setUp(self):
        self.user = UserAdmin.objects.create(id="xyz123", email="mahan@example.com", name="ماهان")

    def test_user_created(self):
        self.assertEqual(self.user.name, "ماهان")