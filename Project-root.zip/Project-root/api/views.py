from rest_framework.response import Response
from rest_framework import viewsets
from .models import DataEntry, UserAdmin
from .serializers import DataEntrySerializer

class DataEntryViewSet(viewsets.ModelViewSet):
    queryset = DataEntry.objects.all()
    serializer_class = DataEntrySerializer

    def create(self, request, *args, **kwargs):
        user_id = request.data.get("user_id")
        entry_data = request.data.get("entry_data")

        user = UserAdmin.objects.filter(id=user_id).first()
        if not user:
            return Response({"message": "کاربر یافت نشد"}, status=404)

        entry = DataEntry.objects.create(user=user, entry_data=entry_data)
        return Response({"message": "اطلاعات ثبت شد", "entry_id": entry.id}, status=201)