from celery import shared_task

@shared_task
def process_json_data(json_data):
    pass