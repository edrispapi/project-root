from django.http import HttpResponse
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
from .models import UserAdmin, Message

def generate_pdf_report():
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="user_messages.pdf"'

    doc = SimpleDocTemplate(response, pagesize=letter)
    elements = []

    data = [["شناسه کاربر", "نام", "ایمیل", "پیام ارسالی", "گیرنده"]]
    for message in Message.objects.all():
        data.append([message.sender.id, message.sender.name, message.sender.email, message.content, message.receiver.name])

    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
    ]))

    elements.append(table)
    doc.build(elements)

    return response