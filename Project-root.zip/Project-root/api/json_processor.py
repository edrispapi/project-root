import json
from .models import CompanyProfile, Address, UserAdmin

def process_json_file(json_data):
    data = json.loads(json_data)
    company = CompanyProfile.objects.create(account_identifier=data["accountIdentifier"])
    return company