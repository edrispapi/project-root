from django.utils.deprecation import MiddlewareMixin

class CustomAuthMiddleware(MiddlewareMixin):
    def process_request(self, request):
        print(f"درخواست جدید از: {request.user}")